**DO NOT EJECT THE SD CARD UNTIL YOU COMPLETE STEP 3**

Step 1: Format new SD card as fat32
Step 2: Flash SD card with ArkOS_K36_v2.0_08112025.img using Rufus or Win32 Disk Imager
Step 3: Copy and paste the .dtb file and extlinux folder to the new boot partition.
Step 4: Eject the SD Card and place into your R36S clone and allow for installation

Warnings: 
- Ejecting the SD Card before replacing the .dtb file and extlinux folder will cause the device to boot using incorrect panel size. Turning off the device before installation of RetroArch completes will cause boot failures and you will need to start the process again.
- Because this was made using the custom .dtb tool, things are not exact. The two main bugs I am troubleshooting so far are the inverted right joystick issue and battery display not being accurate. Power management, from what I can tell, is working just fine.